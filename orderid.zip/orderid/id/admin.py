from django.contrib import admin
from .models import Id
# Register your models here.

admin.site.register(Id)