from django.urls import path
from django.conf.urls import url

from id import models
from . import views

urlpatterns = [
    # path('/', views.main, name="main"),
    path('',models.pre_save_create_order_id)
]