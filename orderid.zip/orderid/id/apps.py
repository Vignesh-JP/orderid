from django.apps import AppConfig


class IdConfig(AppConfig):
    name = 'id'
